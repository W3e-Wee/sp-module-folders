﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SeatBookingSimulator.Classes
{
    internal class Seat
    {
        //This property is used to describe whether the seat "has been selected"
        private bool _bookStatus = false;
        //This property is used to describe that the seat is not bookable at all
        private bool _canBook = false;
        // The _row field is 2 if the object is modelling a seat at row "B".
        private int _row;
        // _column field is 3 if the object is modelling a seat at column 3.
        private int _column;
        public int Row // property
        {
            get { return _row; } // get method
            set
            {
                _row = value;
            } // set method
        }
        public int Column // property
        {
            get { return _column; } // get method
            set { _column = value; } // set method
        }
        public bool CanBook // property
        {
            get { return _canBook; } // get method
            set
            {
                _canBook = value;
            } // set method
        }
        public bool BookStatus // property
        {
            get { return _bookStatus; } // get method
            set
            {
                _bookStatus = value;
            } // set method
        }
        //ComputeSeatLabel is a method defined inside the Seat class
        //ComputeSeatLabel is "not" a property.
        public string ComputeSeatLabel()
        {
            return ((char)(_row + 64)).ToString() + _column.ToString();
        }//End of ComputeSeatLabel



    }//end of Seat class
}//end of Namespace
