﻿using SeatBookingSimulator.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeatBookingSimulator
{
    public partial class Form1 : Form
    {
        SeatDoubleLinkedList seatList = new SeatDoubleLinkedList();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            /*
          Seat s = new Seat();  s.Row = 1;   s.Column = 1;
            seatList.InsertAtEnd(s);
            s = new Seat(); s.Row = 1; s.Column = 2;
            seatList.InsertAtEnd(s);
            s = new Seat(); s.Row = 1;  s.Column = 3;
            seatList.InsertAtEnd(s);
            labelMessage.Text = "Double Linked List has been built";
            

            Label labelSeat = new Label();//Instantiate a new Label type object, labelSeat
            labelSeat.Text = "A1";//Set the Text property by using a string
            labelSeat.Location = new Point(50, 50);//Create a Point type object which has x,y coordinate info
            labelSeat.Size = new Size(60,60);//Create a Size type object which has the width, height info
            labelSeat.TextAlign = ContentAlignment.MiddleCenter;//Align the Text to mid - center
            labelSeat.BorderStyle = BorderStyle.FixedSingle;//Make the border visible
            labelSeat.BackColor = Color.LightBlue;//Set the background color
            labelSeat.Font = new Font("Calibri", 14, FontStyle.Bold);
            labelSeat.ForeColor = Color.Black;
            labelSeat.Tag = new SeatInfo() { Row = 1, Column = 1 };
            // Adding this control to the Panel control, panelSeats
            this.panelSeats.Controls.Add(labelSeat);
            */
        }//End of Form1_Load
        class SeatInfo
        {
            public int Row { get; set; }
            public int Column { get; set; }
        }//End of SeatInfo class

        private void buttonGenerateSeats_Click(object sender, EventArgs e)
        {
            Seat s = new Seat(); s.Row = 1; s.Column = 1;
            seatList.InsertAtEnd(s);
            Label labelSeat = new Label();//Instantiate a new Label type object, labelSeat
            labelSeat.Text = s.ComputeSeatLabel();//Set the Text property by using a string
            labelSeat.Location = new Point(50, 50);//Create a Point type object which has x,y coordinate info
            labelSeat.Size = new Size(60, 60);//Create a Size type object which has the width, height info
            labelSeat.TextAlign = ContentAlignment.MiddleCenter;//Align the Text to mid - center
            labelSeat.BorderStyle = BorderStyle.FixedSingle;//Make the border visible
            labelSeat.BackColor = Color.LightBlue;//Set the background color
            labelSeat.Font = new Font("Calibri", 14, FontStyle.Bold);
            labelSeat.ForeColor = Color.Black;
            labelSeat.Tag = new SeatInfo() { Row = s.Row, Column = s.Column };
            labelSeat.Click += new EventHandler(labelSeat_Click);
            // Adding this control to the Panel control, panelSeats
            this.panelSeats.Controls.Add(labelSeat);

            s = new Seat(); s.Row = 1; s.Column =2;
            seatList.InsertAtEnd(s);
            labelSeat = new Label();//Instantiate a new Label type object, labelSeat
            labelSeat.Text = s.ComputeSeatLabel();//Set the Text property by using a string
            labelSeat.Location = new Point((60 * s.Column)+ (50*(s.Column-1)), 50);//Create a Point type object which has x,y coordinate info
            labelSeat.Size = new Size(60, 60);//Create a Size type object which has the width, height info
            labelSeat.TextAlign = ContentAlignment.MiddleCenter;//Align the Text to mid - center
            labelSeat.BorderStyle = BorderStyle.FixedSingle;//Make the border visible
            labelSeat.BackColor = Color.LightBlue;//Set the background color
            labelSeat.Font = new Font("Calibri", 14, FontStyle.Bold);
            labelSeat.ForeColor = Color.Black;
            labelSeat.Tag = new SeatInfo() { Row = s.Row, Column = s.Column };
            labelSeat.Click += new EventHandler(labelSeat_Click);
            // Adding this control to the Panel control, panelSeats
            this.panelSeats.Controls.Add(labelSeat);

            s = new Seat(); s.Row = 1; s.Column = 3;
            seatList.InsertAtEnd(s);
            labelSeat = new Label();//Instantiate a new Label type object, labelSeat
            labelSeat.Text = s.ComputeSeatLabel();//Set the Text property by using a string
            labelSeat.Location = new Point((60 * s.Column)+(50 * (s.Column - 1)), 50);//Create a Point type object which has x,y coordinate info
            labelSeat.Size = new Size(60, 60);//Create a Size type object which has the width, height info
            labelSeat.TextAlign = ContentAlignment.MiddleCenter;//Align the Text to mid - center
            labelSeat.BorderStyle = BorderStyle.FixedSingle;//Make the border visible
            labelSeat.BackColor = Color.LightBlue;//Set the background color
            labelSeat.Font = new Font("Calibri", 14, FontStyle.Bold);
            labelSeat.ForeColor = Color.Black;
            labelSeat.Tag = new SeatInfo() { Row = s.Row, Column = s.Column };
            labelSeat.Click += new EventHandler(labelSeat_Click);
            // Adding this control to the Panel control, panelSeats
            this.panelSeats.Controls.Add(labelSeat);


        }
        private void labelSeat_Click(object sender, EventArgs e)
        {
            Label label = (Label)sender;
            SeatInfo seatInfo = (SeatInfo)label.Tag;
            //MessageBox.Show(String.Format("Row {0} Column {1}",seatInfo.Row,seatInfo.Column));
           Seat seat =  seatList.SearchByRowAndColumn(seatInfo.Row, seatInfo.Column);
            if (seat.BookStatus == false)
            {
                seat.BookStatus = true;
                label.BackColor = Color.LightGreen;
            }
            else
            {
                seat.BookStatus = false;
                label.BackColor = Color.LightBlue;
            }

        }



    }//End of Form1 class
}//End of namespace
